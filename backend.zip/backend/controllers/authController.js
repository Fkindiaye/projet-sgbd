const mariadb = require('mariadb');
const CryptoJS = require('crypto-js');
const nodemailer = require('nodemailer');
const pool = require('../config/db');
const jwt = require('jsonwebtoken');

function generateCode() {
    return Math.floor(100000 + Math.random() * 900000).toString();
}

async function sendEmail(email, code) {
    let transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: process.env.EMAIL_USER,
            pass: process.env.EMAIL_PASS
        }
    });

    let mailOptions = {
        from: process.env.EMAIL_USER,
        to: email,
        subject: 'Votre code de vérification',
        text: `Votre code de vérification est : ${code}`
    };

    await transporter.sendMail(mailOptions);
}

exports.sendVerificationCode = async (req, res) => {
    const { email } = req.body;
    if (!email) return res.status(400).json({ message: 'Email requis' });

    const code = generateCode();
    const encryptedCode = CryptoJS.AES.encrypt(code, process.env.SECRET_KEY).toString();

    try {
        const conn = await pool.getConnection();
        await conn.query('INSERT INTO codes_verification (email, code) VALUES (?, ?)', [email, encryptedCode]);
        conn.release();

        await sendEmail(email, code);
        res.json({ message: '✅ Code envoyé avec succès' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
exports.verifyCode = async (req, res) => {
    const { email, code } = req.body;
    if (!email || !code) return res.status(400).json({ message: 'Email et code requis' });

    let conn;
    try {
        conn = await pool.getConnection();
        const [result] = await conn.query('SELECT code FROM codes_verification WHERE email = ?', [email]);

        if (!result) {
            conn.release();
            return res.status(400).json({ message: '❌ Code non trouvé' });
        }

        const decryptedCode = CryptoJS.AES.decrypt(result.code, process.env.SECRET_KEY).toString(CryptoJS.enc.Utf8);
        console.log(`📢 Code reçu : ${code}, Code attendu : ${decryptedCode}`); // 🔍 DEBUG

        conn.release();

        if (decryptedCode === code) {
            const token = jwt.sign({ email }, process.env.JWT_SECRET, { expiresIn: '1h' });
            return res.json({ message: '✅ Authentification réussie', token });
        } else {
            return res.status(400).json({ message: '❌ Code incorrect' });
        }
    } catch (error) {
        return res.status(500).json({ error: error.message });
    } finally {
        if (conn) conn.release();
    }
};
