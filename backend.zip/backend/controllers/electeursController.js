const pool = require('../config/db');

// 📌 Ajouter un électeur
exports.ajouterElecteur = async (req, res) => {
    const { cin, numero_electeur, nom, prenom, date_naissance, sexe, bureau_vote } = req.body;

    if (!cin || !numero_electeur || !nom || !prenom || !date_naissance || !sexe || !bureau_vote) {
        return res.status(400).json({ message: "❌ Tous les champs sont obligatoires." });
    }

    try {
        const conn = await pool.getConnection();
        await conn.query(
            'INSERT INTO electeurs (cin, numero_electeur, nom, prenom, date_naissance, sexe, bureau_vote) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [cin, numero_electeur, nom, prenom, date_naissance, sexe, bureau_vote]
        );
        conn.release();
        res.json({ message: '✅ Électeur ajouté avec succès' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// 📌 Récupérer tous les électeurs
exports.getElecteurs = async (req, res) => {
    try {
        const conn = await pool.getConnection();
        const electeurs = await conn.query('SELECT * FROM electeurs');
        conn.release();
        res.json(electeurs);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
