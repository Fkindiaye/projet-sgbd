const pool = require('../config/db');

// 📌 Ajouter un parrainage
exports.ajouterParrainage = async (req, res) => {
    const { numero_electeur, cin_candidat } = req.body;

    if (!numero_electeur || !cin_candidat) {
        return res.status(400).json({ message: "❌ Tous les champs sont obligatoires." });
    }

    try {
        const conn = await pool.getConnection();

        // Vérifier si l’électeur a déjà parrainé un candidat
        const [exists] = await conn.query('SELECT * FROM parrainages WHERE numero_electeur = ?', [numero_electeur]);
        if (exists) {
            conn.release();
            return res.status(400).json({ message: "❌ L’électeur a déjà parrainé un candidat." });
        }

        // Insérer le parrainage
        await conn.query('INSERT INTO parrainages (numero_electeur, cin_candidat) VALUES (?, ?)', [numero_electeur, cin_candidat]);
        conn.release();
        res.json({ message: '✅ Parrainage enregistré avec succès' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// 📌 Récupérer tous les parrainages
exports.getParrainages = async (req, res) => {
    try {
        const conn = await pool.getConnection();
        const parrainages = await conn.query('SELECT * FROM parrainages');
        conn.release();
        res.json(parrainages);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
