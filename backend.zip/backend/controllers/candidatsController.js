const pool = require('../config/db');

// 📌 Ajouter un candidat
exports.ajouterCandidat = async (req, res) => {
    const { cin, nom, prenom, date_naissance, email, telephone, parti_politique } = req.body;

    try {
        const conn = await pool.getConnection();
        await conn.query(
            'INSERT INTO candidats (cin, nom, prenom, date_naissance, email, telephone, parti_politique) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [cin, nom, prenom, date_naissance, email, telephone, parti_politique]
        );
        conn.release();
        res.json({ message: '✅ Candidat ajouté avec succès' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// 📌 Récupérer tous les candidats
exports.getCandidats = async (req, res) => {
    try {
        const conn = await pool.getConnection();
        const candidats = await conn.query('SELECT * FROM candidats');
        conn.release();
        res.json(candidats);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// 📌 Modifier un candidat
exports.modifierCandidat = async (req, res) => {
    const { cin } = req.params;
    const { nom, prenom, date_naissance, email, telephone, parti_politique } = req.body;

    try {
        const conn = await pool.getConnection();
        await conn.query(
            'UPDATE candidats SET nom = ?, prenom = ?, date_naissance = ?, email = ?, telephone = ?, parti_politique = ? WHERE cin = ?',
            [nom, prenom, date_naissance, email, telephone, parti_politique, cin]
        );
        conn.release();
        res.json({ message: '✅ Candidat mis à jour avec succès' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// 📌 Supprimer un candidat
exports.supprimerCandidat = async (req, res) => {
    const { cin } = req.params;

    try {
        const conn = await pool.getConnection();
        await conn.query('DELETE FROM candidats WHERE cin = ?', [cin]);
        conn.release();
        res.json({ message: '✅ Candidat supprimé avec succès' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
