require('dotenv').config();
const express = require('express');
const cors = require('cors');

// ✅ Déclarer `app` en premier
const app = express();

app.use(cors());
app.use(express.json());

// ✅ Importer les routes APRES avoir défini `app`
const authRoutes = require('./routes/auth');
const candidatsRoutes = require('./routes/candidats');

app.use('/api/auth', authRoutes);
app.use('/api/candidats', candidatsRoutes);

const electeursRoutes = require('./routes/electeurs');
const parrainagesRoutes = require('./routes/parrainages');

app.use('/api/electeurs', electeursRoutes);
app.use('/api/parrainages', parrainagesRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`✅ Serveur lancé sur le port ${PORT}`));
