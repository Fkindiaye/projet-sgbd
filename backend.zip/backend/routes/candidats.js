const express = require('express');
const router = express.Router();
const candidatsController = require('../controllers/candidatsController');
const { verifyToken } = require('../middleware/authMiddleware');

// 📌 Routes pour gérer les candidats
router.post('/', verifyToken, candidatsController.ajouterCandidat);
router.get('/', candidatsController.getCandidats);
router.put('/:cin', verifyToken, candidatsController.modifierCandidat);
router.delete('/:cin', verifyToken, candidatsController.supprimerCandidat);

module.exports = router;
