const fs = require('fs');
const csv = require('csv-parser');

router.post('/upload', upload.single('file'), (req, res) => {
    if (!req.file) return res.status(400).json({ message: 'Aucun fichier envoyé' });

    let electeurs = [];

    fs.createReadStream(req.file.path)
        .pipe(csv())
        .on('data', (row) => {
            if (row.cin && row.nom && row.prenom && row.numero_electeur) {
                electeurs.push(row);
            }
        })
        .on('end', async () => {
            try {
                const conn = await pool.getConnection();
                for (let electeur of electeurs) {
                    await conn.query(
                        'INSERT INTO electeurstemporaires (cin, numero_electeur, nom, prenom) VALUES (?, ?, ?, ?)',
                        [electeur.cin, electeur.numero_electeur, electeur.nom, electeur.prenom]
                    );
                }
                conn.release();
                res.json({ message: 'Importation réussie' });
            } catch (error) {
                res.status(500).json({ error: error.message });
            }
        });
});
