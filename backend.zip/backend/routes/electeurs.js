const express = require('express');
const router = express.Router();
const electeursController = require('../controllers/electeursController');
const { verifyToken } = require('../middleware/authMiddleware');

// 📌 Routes pour gérer les électeurs
router.post('/', verifyToken, electeursController.ajouterElecteur);
router.get('/', verifyToken, electeursController.getElecteurs);

module.exports = router;
