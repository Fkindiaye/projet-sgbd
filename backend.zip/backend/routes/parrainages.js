const express = require('express');
const router = express.Router();
const parrainagesController = require('../controllers/parrainagesController');
const { verifyToken } = require('../middleware/authMiddleware');

// 📌 Routes pour gérer les parrainages
router.post('/', verifyToken, parrainagesController.ajouterParrainage);
router.get('/', verifyToken, parrainagesController.getParrainages);

module.exports = router;
