const API_URL = 'http://localhost:5000/api';

export const uploadCSV = async (file) => {
    const formData = new FormData();
    formData.append('file', file);

    const response = await fetch(`${API_URL}/upload`, {
        method: 'POST',
        body: formData
    });

    return response.json();
};

export const sendVerificationCode = async (email) => {
    const response = await fetch(`${API_URL}/auth/send-code`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
    });

    return response.json();
};

export const verifyCode = async (email, code) => {
    const response = await fetch(`${API_URL}/auth/verify-code`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, code })
    });

    return response.json();
};
