import React, { useState } from 'react';
import { sendVerificationCode, verifyCode } from '../services/api';

const Login = () => {
    const [email, setEmail] = useState('');
    const [code, setCode] = useState('');
    const [step, setStep] = useState(1);

    const handleSendCode = async () => {
        await sendVerificationCode(email);
        setStep(2);
    };

    const handleVerifyCode = async () => {
        const result = await verifyCode(email, code);
        alert(result.message);
    };

    return (
        <div>
            {step === 1 ? (
                <>
                    <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
                    <button onClick={handleSendCode}>Envoyer le code</button>
                </>
            ) : (
                <>
                    <input type="text" placeholder="Code" value={code} onChange={(e) => setCode(e.target.value)} />
                    <button onClick={handleVerifyCode}>Valider</button>
                </>
            )}
        </div>
    );
};

export default Login;
