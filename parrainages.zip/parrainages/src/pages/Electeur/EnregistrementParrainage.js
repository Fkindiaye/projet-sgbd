import React, { useState } from "react";
import axios from "axios";

const EnregistrementParrainage = () => {
    const [step, setStep] = useState(1);
    const [formData, setFormData] = useState({
        numeroElecteur: "",
        cin: "",
        codeAuth: "",
        candidatChoisi: null,
        codeValidation: ""
    });

    const [electeurInfo, setElecteurInfo] = useState(null);
    const [candidats, setCandidats] = useState([]);
    const [message, setMessage] = useState("");

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    // Vérifier les informations de l'électeur
    const verifierElecteur = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post("http://localhost:5000/parrains/verifier", {
                numeroElecteur: formData.numeroElecteur,
                cin: formData.cin
            });

            setElecteurInfo(response.data);
            setStep(2);
        } catch (error) {
            setMessage("Informations incorrectes ou électeur non inscrit.");
        }
    };

    // Vérifier le code d'authentification
    const verifierCodeAuth = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post("http://localhost:5000/parrains/authentifier", {
                numeroElecteur: formData.numeroElecteur,
                codeAuth: formData.codeAuth
            });

            setCandidats(response.data.candidats);
            setStep(3);
        } catch (error) {
            setMessage("Code incorrect ou expiré.");
        }
    };

    // Sélectionner un candidat
    const choisirCandidat = (candidatId) => {
        setFormData({ ...formData, candidatChoisi: candidatId });
    };

    // Demander un code de validation
    const demanderCodeValidation = async () => {
        try {
            await axios.post("http://localhost:5000/parrains/demanderCode", {
                numeroElecteur: formData.numeroElecteur,
                candidatId: formData.candidatChoisi
            });

            setStep(4);
        } catch (error) {
            setMessage("Erreur lors de l'envoi du code.");
        }
    };

    // Valider le parrainage
    const validerParrainage = async (e) => {
        e.preventDefault();
        try {
            await axios.post("http://localhost:5000/parrains/valider", {
                numeroElecteur: formData.numeroElecteur,
                codeValidation: formData.codeValidation
            });

            setStep(5);
        } catch (error) {
            setMessage("Code de validation incorrect.");
        }
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-r from-blue-500 to-indigo-600 p-6">
            <div className="bg-white p-8 rounded-lg shadow-xl w-full max-w-md">
                <h2 className="text-2xl font-bold text-center text-blue-600 mb-6">Enregistrement Parrainage</h2>

                {message && <p className="text-red-600 text-center">{message}</p>}

                {step === 1 && (
                    <form onSubmit={verifierElecteur} className="space-y-4">
                        <input type="text" name="numeroElecteur" placeholder="Numéro électeur" onChange={handleChange} required className="w-full p-3 border rounded" />
                        <input type="text" name="cin" placeholder="Numéro CNI" onChange={handleChange} required className="w-full p-3 border rounded" />
                        <button type="submit" className="w-full bg-blue-600 text-white p-3 rounded-lg hover:bg-blue-700">Vérifier</button>
                    </form>
                )}

                {step === 2 && electeurInfo && (
                    <div>
                        <p><strong>Nom :</strong> {electeurInfo.nom}</p>
                        <p><strong>Date de naissance :</strong> {electeurInfo.dateNaissance}</p>
                        <p><strong>Bureau de vote :</strong> {electeurInfo.bureauVote}</p>

                        <form onSubmit={verifierCodeAuth} className="mt-4">
                            <input type="text" name="codeAuth" placeholder="Code d’authentification" onChange={handleChange} required className="w-full p-3 border rounded" />
                            <button type="submit" className="w-full bg-green-600 text-white p-3 rounded-lg hover:bg-green-700 mt-2">Vérifier Code</button>
                        </form>
                    </div>
                )}

                {step === 3 && (
                    <div>
                        <h3 className="text-lg font-bold">Choisir un candidat :</h3>
                        <ul>
                            {candidats.map((candidat) => (
                                <li key={candidat.id} className="flex items-center space-x-4 p-2 border rounded">
                                    <img src={candidat.photo} alt={candidat.nom} className="w-12 h-12 rounded-full" />
                                    <span>{candidat.nom} ({candidat.parti})</span>
                                    <button onClick={() => choisirCandidat(candidat.id)} className="bg-blue-500 text-white px-3 py-1 rounded">Sélectionner</button>
                                </li>
                            ))}
                        </ul>
                        <button onClick={demanderCodeValidation} className="w-full bg-yellow-500 text-white p-3 rounded-lg hover:bg-yellow-600 mt-4">Recevoir Code</button>
                    </div>
                )}

                {step === 4 && (
                    <form onSubmit={validerParrainage}>
                        <input type="text" name="codeValidation" placeholder="Code reçu" onChange={handleChange} required className="w-full p-3 border rounded" />
                        <button type="submit" className="w-full bg-green-500 text-white p-3 rounded-lg hover:bg-green-600 mt-2">Valider</button>
                    </form>
                )}

                {step === 5 && <p className="text-green-600 text-center">Parrainage validé avec succès !</p>}
            </div>
        </div>
    );
};

export default EnregistrementParrainage;
