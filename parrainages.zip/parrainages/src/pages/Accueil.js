import React from "react";
import { Container, Row, Col, Card, Button } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUsers, faUserTie, faCheckSquare } from "@fortawesome/free-solid-svg-icons";
import { Link } from "react-router-dom";
import "./Accueil.css";

const Accueil = () => {
  return (
    <Container className="accueil-container text-center">
      <h1 className="mt-5">Gestion des Parrainages</h1>
      <Row className="mt-4">
        {/* DGE */}
        <Col md={4}>
          <Card className="accueil-card">
            <Card.Body>
              <FontAwesomeIcon icon={faUsers} className="icon" />
              <Card.Title>DGE</Card.Title>
              <Card.Text>
                Gérer les fichiers électoraux et superviser le parrainage.
              </Card.Text>
              <Link to="/upload-electeurs">
                <Button variant="primary">Accéder</Button>
              </Link>
            </Card.Body>
          </Card>
        </Col>

        {/* Candidats */}
        <Col md={4}>
          <Card className="accueil-card">
            <Card.Body>
              <FontAwesomeIcon icon={faUserTie} className="icon" />
              <Card.Title>Candidats</Card.Title>
              <Card.Text>
                Suivez l'évolution de vos parrainages et gérez votre profil.
              </Card.Text>
              <Link to="/suivi-parrainages">
                <Button variant="primary">Accéder</Button>
              </Link>
            </Card.Body>
          </Card>
        </Col>

        {/* Électeurs */}
        <Col md={4}>
          <Card className="accueil-card">
            <Card.Body>
              <FontAwesomeIcon icon={faCheckSquare} className="icon" />
              <Card.Title>Électeurs</Card.Title>
              <Card.Text>
                Parrainer un candidat de manière sécurisée.
              </Card.Text>
              <Link to="/enregistrement-parrain">
                <Button variant="primary">Accéder</Button>
              </Link>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default Accueil;
