import React, { useState } from "react";
import { Form, Button, Alert, Table } from "react-bootstrap";
import axios from "axios";

const SuiviParrainages = () => {
  const [email, setEmail] = useState("");
  const [codeAuth, setCodeAuth] = useState("");
  const [candidat, setCandidat] = useState(null);
  const [parrainages, setParrainages] = useState([]);
  const [error, setError] = useState("");

  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");

    try {
      const response = await axios.post("http://localhost:5000/api/candidats/login", {
        email,
        codeAuth,
      });

      if (response.data.success) {
        setCandidat(response.data.candidat);
        fetchParrainages(response.data.candidat.cin);
      } else {
        setError("Échec de l'authentification");
      }
    } catch (err) {
      setError("Email ou code incorrect");
    }
  };

  const fetchParrainages = async (cin) => {
    try {
      const response = await axios.get(`http://localhost:5000/api/candidats/parrainages/${cin}`);
      setParrainages(response.data);
    } catch (err) {
      setError("Erreur lors du chargement des parrainages");
    }
  };

  return (
    <div className="container mt-5">
      <h2>Suivi des Parrainages</h2>
      {error && <Alert variant="danger">{error}</Alert>}

      {!candidat ? (
        <Form onSubmit={handleLogin}>
          <Form.Group className="mb-3">
            <Form.Label>Email</Form.Label>
            <Form.Control
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </Form.Group>
          <Form.Group className="mb-3">
            <Form.Label>Code d'authentification</Form.Label>
            <Form.Control
              type="text"
              value={codeAuth}
              onChange={(e) => setCodeAuth(e.target.value)}
              required
            />
          </Form.Group>
          <Button variant="primary" type="submit">Se connecter</Button>
        </Form>
      ) : (
        <div>
          <h4>Bonjour {candidat.nom}, voici vos statistiques de parrainage :</h4>
          <Table striped bordered hover>
            <thead>
              <tr>
                <th>Date</th>
                <th>Nombre de Parrainages</th>
              </tr>
            </thead>
            <tbody>
              {parrainages.map((p, index) => (
                <tr key={index}>
                  <td>{p.date}</td>
                  <td>{p.total}</td>
                </tr>
              ))}
            </tbody>
          </Table>
        </div>
      )}
    </div>
  );
};

export default SuiviParrainages;
