import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import UploadElecteurs from './pages/DGE/UploadElecteurs';
import SaisieCandidats from './pages/DGE/SaisieCandidats';
import OuvertureParrainage from './pages/DGE/OuvertureParrainage'; // Importation correcte
import EnregistrementParrain from './pages/Electeur/EnregistrementParrain';
import EnregistrementParrainage from './pages/Electeur/EnregistrementParrainage';
import SuiviParrainages from './pages/Candidat/SuiviParrainages';
import Navigation from './components/Navigation';
import './styles.css';


function App() {
  return (
    <Router>
      <div className="App">
        <Navigation />
        <Routes>
          <Route path="/upload-electeurs" element={<UploadElecteurs />} />
          <Route path="/saisie-candidats" element={<SaisieCandidats />} />
          <Route path="/ouverture-parrainage" element={<OuvertureParrainage />} /> {/* Utilisation de OuvertureParrainage */}
          <Route path="/enregistrement-parrain" element={<EnregistrementParrain />} />
          <Route path="/suivi-parrainages" element={<SuiviParrainages />} />
          <Route path="/" element={<h1 className="text-center mt-5">Bienvenue sur la plateforme de parrainage</h1>} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;